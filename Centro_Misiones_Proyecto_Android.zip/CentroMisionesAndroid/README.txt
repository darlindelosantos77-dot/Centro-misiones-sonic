CENTRO DE MISIONES SONIC — PROYECTO ANDROID (WEBVIEW)

Este proyecto empaqueta el HTML original en una aplicación Android. Las misiones y el guardado local funcionan dentro de WebView mediante JavaScript y DOM Storage. El contenido principal está incluido en app/src/main/assets/index.html, así que no necesita Netlify ni conexión a Internet para abrirse.

PARA GENERAR EL APK:
1. Abre este proyecto en Android Studio (opción Open).
2. Espera a que Gradle sincronice y descargue las herramientas necesarias.
3. Selecciona Build > Build Bundle(s) / APK(s) > Build APK(s).
4. Al terminar, pulsa Locate. El APK de prueba estará en app/build/outputs/apk/debug/app-debug.apk.
5. Pasa ese APK al teléfono Android, ábrelo y sigue la instalación. Android puede pedir permiso para instalar desde esa fuente.

REQUISITOS:
- Android Studio en una computadora.
- Android SDK 35 y JDK 17 (Android Studio puede instalar/configurar el SDK).
- Este ZIP es el proyecto fuente; todavía no es un APK compilado.

IMPORTANTE:
- El progreso queda guardado en el almacenamiento de la aplicación en ese teléfono.
- Si desinstalas la aplicación, Android puede borrar ese progreso.
- No se añadió permiso de Internet: la app carga el HTML incluido localmente.
